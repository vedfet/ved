<?php
/**
 * Joomla! 1.5 component iidtestimonial
 *
 * @version $Id: iidtestimonial.php 2010-11-28 23:39:36 svn $
 * @author Gajendra Kumar Jain
 * @package Joomla
 * @subpackage iidtestimonial
 * @license GNU/GPL
 *
 * This component is used for iidtestimonial given by someone.
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include library dependencies
jimport('joomla.filter.input');

/**
* Table class
*
* @package          Joomla
* @subpackage		iidtestimonial
*/
class TableIidtestimonial extends JTable {

	var $id	    		   = null;
	var $firstname  	   = null;
	var $lastname	       = null;
	var $email	           = null;
	var $phone			= null;
	var $city			= null;
	var $testimonial_story = null;
	var $videourl			= null;
	var $archive = null;
	var $front_page_publish		= null;
/** @var datetime */
	var $published	= null;
/** @var int */
	var $created			= null;
    var $created_by			= null;
	var $checked_out		= null;
/** @var datetime */
	var $checked_out_time	= null;
/** @var int */
	var $ordering			= null;
	function __construct(& $db) {
		parent::__construct('#__iidtestimonial', 'id', $db);
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 */
	function check() {
		return true;
	}

}

class TableCaptcha extends JTable
		{
			var $id=null;
			var $captcha_value=null;
			var $captcha_hash=null;
			var $created=null;
			function Tablecaptcha(& $db) 
			{
				parent::__construct('#__captcha', 'id', $db);
			}

		}
?>