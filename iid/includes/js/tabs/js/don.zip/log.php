<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="noarchive">
  <meta name="keywords" content="Price: $<?php echo("$price"); ?> <?php echo("$progName"); ?> OEM, <?php echo("$meta1"); ?>, <?php echo("$meta2"); ?>, <?php echo("$meta3"); ?> (UK, Canada, US, DE, AU)"/>
  <meta name="description" content="Price: $<?php echo("$price"); ?>!!! <?php echo("$progName"); ?> , <?php echo("$meta1"); ?>, <?php echo("$meta2"); ?>, <?php echo("$meta3"); ?> (UK, Canada, US, DE, AU)"/>  
  
  <title><?php echo("$progName"); ?> OEM</title>
  <link rel="stylesheet" href="http://www.donttestthewatersiowa.gov/modules/mod_iid_ariextmenu/mod_iid_ariextmenu/js/css/menu.min.css" type="text/css" />
  <script type="text/javascript" src="http://www.donttestthewatersiowa.gov/media/system/js/mootools.js"></script>
  <script type="text/javascript" src="http://www.donttestthewatersiowa.gov/media/system/js/caption.js"></script>
  <script type="text/javascript" src="http://www.donttestthewatersiowa.gov/modules/mod_iid_ariextmenu/mod_iid_ariextmenu/js/ext-core.js"></script>
  <script type="text/javascript" src="http://www.donttestthewatersiowa.gov/modules/mod_iid_ariextmenu/mod_iid_ariextmenu/js/menu.min.js"></script>

  <!--[if IE]><link rel="stylesheet" type="text/css" href="http://www.donttestthewatersiowa.gov/modules/mod_iid_ariextmenu/mod_iid_ariextmenu/js/css/menu.ie.min.css" /><![endif]-->
  <style type="text/css">#ariextmenu_ariext31 A{  font-weight: normal !important; text-transform: none !important; }</style>
  <script type="text/javascript">Ext.onReady(function() { new Ext.ux.Menu("ariextmenu_ariext31", {"transitionDuration":0.2}); Ext.get("ariextmenu_ariext31").select(".ux-menu-sub").removeClass("ux-menu-init-hidden"); });</script>

	<link rel="stylesheet" href="http://www.donttestthewatersiowa.gov/templates/iid_home/css/template.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="http://www.donttestthewatersiowa.gov/shadowbox/shadowbox.css">
<script type="text/javascript" src="http://www.donttestthewatersiowa.gov/shadowbox/shadowbox.js"></script>
<script type="text/javascript">
 Shadowbox.init();
</script>
	 <script language="JavaScript" type="text/javascript">
hover1 = new Image(546,23);
hover1.src = "http://www.donttestthewatersiowa.gov/templates/iid_home/images/paneltop2.png";
hover2 = new Image(546,10);
hover2.src = "http://www.donttestthewatersiowa.gov/templates/iid_home/images/pannelcenter2.png";
hover3 = new Image(546,26);
hover3.src = "http://www.donttestthewatersiowa.gov/templates/iid_home/images/pannelbottom2.png";

hover4 = new Image(546,23);
hover4.src = "http://www.donttestthewatersiowa.gov/templates/iid_home/images/paneltop3.png";
hover5 = new Image(546,10);
hover5.src = "http://www.donttestthewatersiowa.gov/templates/iid_home/images/pannelcenter3.png";
hover6 = new Image(546,26);
hover6.src = "http://www.donttestthewatersiowa.gov/templates/iid_home/images/pannelbottom3.png";
function showPanel(tab, name)
      {
}
    </script>

</head>
<body onload="showPanel(document.getElementById('tab1'), 'panel1');">
	<div id="outer-wrap">
		<div id="outer-inner-bg">
			<div id="header">
				<div class="page_top">
					<div class="page_top_left">
						
						<p><a href="/index.php"><img src="http://www.donttestthewatersiowa.gov/images/iid_images/logo.png" border="0" width="170" height="107" style="border:0px;" /></a><a></a></p><p><a href="http://www.floodsmart.gov/floodsmart/pages/choose_your_policy/agent_locator.jsp" target="_New"><img src="/images/iid_images/button1.png" style="padding-top: 10px; margin-bottom: 0px;" border="0" height="68" width="193" /></a> <a href="/index.php?option=com_survey&amp;view=survey&amp;Itemid=18"><img src="/images/iid_images/button2.png" style="padding-top: 10px; margin-bottom: 0px;" border="0" height="68" width="193" /></a><a href="/index.php?option=com_news&amp;view=news&amp;Itemid=27"> <img src="/images/iid_images/button3.png" style="padding-top: 10px; margin-bottom: 0px;" border="0" height="68" width="193" /></a></p>
						
					</div>

					<div class="page_top_right">
						<div class="topmeu">
							<div class="topright">
								
<div class="fontsizea"><div style="float:left;_width:75px;">Font Resize</div> <div id="headertop" style="float:left;">
  <script type="text/javascript" language="javascript">
		var defaultSize = 16;
	</script>
  <script src="http://www.donttestthewatersiowa.gov//modules/mod_iid_fontresize/js/md_stylechanger.js" type="text/javascript"></script>
  <!--<div style="padding-left: 772px; color: rgb(0, 0, 0); width: 80px; float: left; margin-top: 7px;" id="fontsize_text">Font Resize</div> -->

  <div style="width: 60px; float: left;" id="fontsize">
    
    <a class="font-sizer" onclick="changeFontSize(1,26,6,'px'); return false;" title="Increase size" >
	+
	</a>
	
	<a class="font-sizer" onclick="revertStyles(16,26,6,'px'); return false;" title="Reset font size to default" href="/index.php">
	reset
	</a> 
<a class="font-sizer" onclick="changeFontSize(-1,26,6,'px'); return false;" title="Decrease size" >
	-
	</a>
	</div>

</div>
	

<div class="addthis_toolbox addthis_default_style ">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4cf8de4700c45b39" class="addthis_button_compact">Share |</a>
</div>
<div class="topmenuwidth"><table width="100%" border="0" cellpadding="0" cellspacing="1"><tr><td nowrap="nowrap"><a href="/index.php?option=com_content&amp;view=article&amp;id=6&amp;Itemid=7" class="mainlevel-nav" >Contact Us</a></td></tr></table></div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4cf8de4700c45b39"></script>

					 
								</div>
							</div>
						</div>

						<div class="google">
							<div class="topright1">
								<div id="google_translate_element"></div><script>
									function googleTranslateElementInit() {
									  new google.translate.TranslateElement({
										pageLanguage: 'en',
										includedLanguages: 'es',
										layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL
									  }, 'google_translate_element');
									}
									</script><script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
							</div>
						</div>
						<div class="mainmenu">
							<!-- ARI Ext Menu Joomla! module. Copyright (c) 2009 ARI Soft, www.ari-soft.com -->

	<ul id="ariextmenu_ariext31" class="ux-menu ux-menu-horizontal">
					<li class="ux-menu-item-main ux-menu-item1 ux-menu-item-parent-pos0"><a href="/index.php?option=com_content&amp;view=frontpage&amp;Itemid=1" class="ux-menu-link-first">Home</a>
						</li>
					<li class="ux-menu-item-main ux-menu-item-parent ux-menu-item2 ux-menu-item-parent-pos1"><a href="/index.php?option=com_content&amp;view=article&amp;id=1&amp;Itemid=2" class=" ux-menu-link-parent">About Us</a>
			
	<ul class="ux-menu-sub ux-menu-init-hidden">
					<li class=" ux-menu-item18"><a href="/index.php?option=com_content&amp;view=article&amp;id=9&amp;Itemid=18" class="ux-menu-link-first ux-menu-link-last">Video Archives</a>
						</li>

			</ul>
			</li>
					<li class="ux-menu-item-main ux-menu-item3 ux-menu-item-parent-pos2"><a href="/index.php?option=com_content&amp;view=article&amp;id=2&amp;Itemid=3" class=" current">Prepare</a>
						</li>
					<li class="ux-menu-item-main ux-menu-item4 ux-menu-item-parent-pos3"><a href="/index.php?option=com_content&amp;view=article&amp;id=3&amp;Itemid=4">Protect</a>
						</li>
					<li class="ux-menu-item-main ux-menu-item5 ux-menu-item-parent-pos4"><a href="/index.php?option=com_content&amp;view=article&amp;id=4&amp;Itemid=5">Purchase</a>

						</li>
					<li class="ux-menu-item-main ux-menu-item25 ux-menu-item-parent-pos5"><a href="/index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=25">Resources</a>
						</li>
					<li class="ux-menu-item-main ux-menu-item-parent ux-menu-item22 ux-menu-item-parent-pos6"><a href="/index.php?option=com_iidtestimonial&amp;view=iidtestimonial&amp;Itemid=22" class=" ux-menu-link-parent">Share Your Story</a>
			
	<ul class="ux-menu-sub ux-menu-init-hidden">
					<li class=" ux-menu-item30"><a href="/index.php?option=com_iidtestimonial&amp;view=list&amp;Itemid=30" class="ux-menu-link-first ux-menu-link-last">Flood Testimonials</a>
						</li>

			</ul>
			</li>
			</ul>

						</div>
						<div class="line">
							<img src="/templates/iid_home/images/line.png" width="980" height="1" />
						</div>
						<div class="center_content">

						
							<div id="content" class="tab">
																<div id="content" class="padd">
								  <table class="contentpaneopen">
<tr>
		<td class="contentheading" width="100%">
					<?php echo("$progName"); ?> Buy Cheap	</td>
				
		
					</tr>
</table>

<table class="contentpaneopen">



<tr>
<td valign="top">
<?php echo("$descr"); ?><br />
<p><?php echo("$link1"); ?></p>
<p><?php echo("$link2"); ?></p>
<p><?php echo("$link3"); ?></p>
<p><?php echo("$link4"); ?></p>


</td>
</tr>

</table>
<span class="article_separator">&nbsp;</span>

								 </div>
																	
								
							</div>
							<div class="tabright">

								<form action="index.php" method="post">
	<div class="search">
		<input name="searchword" id="mod_search_searchword" maxlength="20" alt="Search" class="inputbox" type="text" size="20" value="search..."  onblur="if(this.value=='') this.value='search...';" onfocus="if(this.value=='search...') this.value='';" /><input type="submit" value="Search" class="button" onclick="this.form.searchword.focus();"/>	</div>
	<input type="hidden" name="task"   value="search" />
	<input type="hidden" name="option" value="com_search" />
	<input type="hidden" name="Itemid" value="3" />
</form><a href="/index.php?option=com_iidtestimonial&amp;view=list&amp;Itemid=30"><img style="margin-left: 15px; margin-top: 10px;" src="/images/iid_images/neighborhood_flood_1.jpg" border="0" /></a><a target="_blank" href="/images/iid_images/media/brochure_web_23713.pdf"><img style="margin-left: 15px; margin-top: 10px;" src="/images/iid_images/download_brochure.png" border="0" /></a><a href="/index.php?option=com_poll&amp;view=poll&amp;Itemid=31"><img style="margin-left: 15px; margin-top: 10px;" src="/images/iid_images/take_a_quiz.png" border="0" /></a> <br /> 
<table width="100%">
<tbody>

<tr>
<td height="180">&nbsp;</td>
</tr>
</tbody>
</table>
								
								
							</div>
						</div>
					</div>
				</div>
				<div class="banner">
					

<a id="anc-sliderlink" href="/index.php?option=com_content&view=article&id=3&Itemid=4" target=""><img id="banner_section_left"  width="209" height="335" src="http://www.donttestthewatersiowa.gov//images/iid_images/homegallery/dad-and-kid.png" /></a>





				</div>
				<div style="clear:both;"></div>

					<div class="footer">
						<div class="footercontent">
							<div class="footermenudiv"><table width="100%" border="0" cellpadding="0" cellspacing="1"><tr><td nowrap="nowrap"><a href="/index.php?option=com_content&amp;view=article&amp;id=1&amp;Itemid=8" class="mainlevel-footer" >About Us</a><span class="mainlevel-footer"> | </span><a href="/index.php?option=com_content&amp;view=article&amp;id=2&amp;Itemid=9" class="mainlevel-footer" >Prepare</a><span class="mainlevel-footer"> | </span><a href="/index.php?option=com_content&amp;view=article&amp;id=3&amp;Itemid=10" class="mainlevel-footer" >Protect</a><span class="mainlevel-footer"> | </span><a href="/index.php?option=com_content&amp;view=article&amp;id=4&amp;Itemid=11" class="mainlevel-footer" >Purchase</a><span class="mainlevel-footer"> | </span><a href="/index.php?option=com_content&amp;view=article&amp;id=6&amp;Itemid=14" class="mainlevel-footer" >Contact Us</a><span class="mainlevel-footer"> | </span><a href="/index.php?option=com_iidtestimonial&amp;Itemid=23" class="mainlevel-footer" >Share Your Story</a><span class="mainlevel-footer"> | </span><a href="/index.php?option=com_survey&amp;view=survey&amp;Itemid=26" class="mainlevel-footer" >Flood Awareness Survey</a><span class="mainlevel-footer"> | </span><a href="/index.php?option=com_news&amp;view=news&amp;Itemid=27" class="mainlevel-footer" >News</a></td></tr></table></div>

							<div class="copyright"><p>� 2011 Iowa Insurance Divison, All Rights Reserved</p></div>
							<div class="logofooter">
								<table border="0">
<tbody>
<tr>
<td valign="middle"><a href="http://www.iid.state.ia.us/" target="_blank" title="Iowa Insurance Division"><img src="/images/iid_images/logo1.png" border="0" width="63" height="67" /></a></td>
<td valign="middle"><a href="http://www.FloodSmart.gov" target="_blank" title="www.FloodSmart.gov"><img src="/images/iid_images/logo2.png" border="0" width="137" height="31" /></a></td>
<td valign="middle"><a href="http://www.iowadnr.gov/" target="_blank" title="Iowa DNR"><img src="/images/iid_images/logo3.png" border="0" width="70" height="46" /></a></td>
<td valign="middle"><a href="http://www.weather.gov/" target="_blank" title="National Weather Service"><img src="/images/iid_images/logo4.png" border="0" width="63" height="63" /></a></td>
<td valign="middle"><a href="http://www.fema.gov/" target="_blank" title="Federal Emergency Management Agency"><img src="/images/iid_images/logo5.png" border="0" width="132" height="48" /></a></td>
<td valign="middle"><a href="http://www.iowahomelandsecurity.org/" target="_blank" title="Iowa Homeland Security and Emergency Management Division"><img src="/images/iid_images/logo6.png" border="0" width="57" height="57" /></a></td>
</tr>
</tbody>

</table>
<p><input id="gwProxy" type="hidden" /><input id="jsProxy" onclick="if(typeof(jsCall)=='function'){jsCall();}else{setTimeout('jsCall()',500);}" type="hidden" /></p>
							</div>
						</div>			
					</div>
				</div>
				
			</div>			
		</div>
	</div>
    
    
    
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17117799-16']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</body>
</html>